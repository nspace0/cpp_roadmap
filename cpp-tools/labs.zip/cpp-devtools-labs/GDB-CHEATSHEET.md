# GDB: опорные команды, CT04–CT09
Подготовка: g++ -std=c++20 -g -Og -fno-omit-frame-pointer main.cpp -o app
Запуск: gdb --args ./app аргументы
-g добавляет сведения, -Og выбирает оптимизацию для отладки. Не все переменные обязаны существовать в каждой точке. Сверяй gdb --version и help.

| Команда | Назначение |
|---|---|
| break main / break file.cpp:20 | Точка по функции / исполнимой строке |
| break step_value if index == 2 | Условная точка |
| info breakpoints | Точки и число срабатываний |
| disable 2 / enable 2 / delete 2 | Управление точкой №2 |
| run / continue | Новый запуск / продолжение |
| next / step / finish | Строка без входа / с входом / до возврата |
| nexti / stepi | Инструкция с обходом / входом в call |
| bt / frame 2 / up / down | Стек и выбранный кадр просмотра |
| info args / info locals | Аргументы и локальные значения |
| print value / print/x value / ptype value | Значение / hex / тип |
| display value / undisplay 1 | Автоматический вывод / отмена |
| x/4xb data / x/4dw data | Четыре байта hex / четыре 4-байтных значения |
| x/8gx $rsp / x/6i $pc | Стек x86-64 / инструкции |
| info registers | Регистры |
| disassemble /r function | Инструкции и байты |
| disassemble /s function | Смешанный листинг; /m устарел |
| set disassembly-flavor intel | Intel-синтаксис x86 |
| watch watched | Изменение значения; аппаратные ограничения |
| info threads / thread 2 | Потоки и выбор |
| thread apply all bt | Стеки потоков |
| catch throw / info signals | Исключения / политика сигналов |
| attach PID / detach | Подключение к своему разрешённому процессу / освобождение |
| quit | Выход; прочитай вопрос о живом процессе |

Выбор frame не выполняет процесс назад. Адреса, номера точек и потоки — разные сущности.
Разыменовывай осмысленные адреса живых объектов; print с вызовом функции способен менять процесс.

Дамп: gdb ./exact-app ./core — точный бинарник и соответствующие символы.
Core зависит от ulimit/core_pattern/systemd; файл рядом с программой не гарантирован.
Журнал: set logging file session.log; set logging overwrite on; set logging enabled on; затем set logging enabled off. Вводи как отдельные команды.
Batch: gdb -q -batch -x checks.gdb --args ./app. Скрипт должен давать ненулевой выход при нарушении ожиданий.

Remote через SSH stdio после file ./matching-app:
~~~text
target remote | ssh -T user@host gdbserver - /absolute/path/app
~~~
Подставь свой согласованный стенд. Нужны SSH, gdbserver, совпадающие бинарник/символы и архитектура.
host в gdbserver host:port не гарантирует loopback bind, поэтому здесь stdio через SSH. Не публикуй незащищённый debug-порт.

| Симптом | Проверка |
|---|---|
| No debugging symbols | Точный бинарник, -g и отдельный debug-файл |
| optimized out | Оптимизация, время жизни, точка остановки |
| No symbol in current context | Кадр и область видимости |
| Cannot access memory | Адрес и время жизни |
| Breakpoint pending | Загрузка модуля и имя |
| Operation not permitted | Ограничения среды и разрешения |
| Нет core | Политика сбора и хранения |

Сохрани исходную сборку: смена оптимизации и отладчик могут менять проявление ошибки.
