#include "core.hpp"
#include <iostream>
int main() {
    const int cases[][3] = {{2,3,5},{-2,2,0},{0,0,0},{-3,-4,-7}};
    for (const auto& c : cases) {
        if (const int actual = add(c[0],c[1]); actual != c[2]) {
            std::cerr << "add(" << c[0] << ',' << c[1] << ") expected "
                      << c[2] << " got " << actual << '\n';
            return 1;
        }
    }
    std::cout << "4 addition cases passed\n";
}
