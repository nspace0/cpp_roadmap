#pragma once
// Contract: a + b must fit in int.
int add(int a, int b);
