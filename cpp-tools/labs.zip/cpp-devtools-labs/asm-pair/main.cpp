#include <cstdint>
#include <iostream>
#include <limits>
extern "C" std::uint64_t add_u64(std::uint64_t, std::uint64_t);
int main() {
    const std::uint64_t cases[][2] = {
        {0, 0}, {1, 2},
        {std::numeric_limits<std::uint64_t>::max(), 1},
        {0x8000000000000000ULL, 0x8000000000000000ULL}
    };
    for (const auto& p : cases) {
        const auto expected = p[0] + p[1];
        if (add_u64(p[0], p[1]) != expected) return 1;
    }
    std::cout << "4 cases passed\n";
}
