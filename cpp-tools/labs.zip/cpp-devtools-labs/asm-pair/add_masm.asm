option casemap:none
PUBLIC add_u64
.code
add_u64 PROC
    lea rax, [rcx + rdx]
    ret
add_u64 ENDP
END
