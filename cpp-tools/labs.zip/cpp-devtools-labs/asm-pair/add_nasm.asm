bits 64
global add_u64:function
section .text
add_u64:
    lea rax, [rdi + rsi]
    ret
section .note.GNU-stack noalloc noexec nowrite progbits
