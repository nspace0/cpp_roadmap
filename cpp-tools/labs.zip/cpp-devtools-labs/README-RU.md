# Лаборатории ассемблера и инструментов C/C++
Редакция 2026-10-26. Три независимых проекта. Архив не устанавливает инструменты.
Карты: https://nspace0.github.io/cpp_roadmap/assembly/ и https://nspace0.github.io/cpp_roadmap/cpp-tools/

## Первый вечер — CT01.1 и AX01.1
Запиши ОС, архитектуру, оболочку и версии инструментов.
Windows: x64 Developer Command Prompt с компонентами C++; where cl, where ml64, cmake --version, ninja --version.
Linux/WSL/Kubuntu: Bash; g++ --version, gdb --version, cmake --version.
Отсутствующие пакеты своей Ubuntu: sudo apt update, затем sudo apt install build-essential gdb cmake ninja-build nasm git.
На Windows CMake/Ninja и C++ устанавливаются компонентами Visual Studio Installer.
WSL-копию удобно хранить в ~/projects, Windows-копию — отдельно. Через Git переносится исходник; build между ОС не переносится.

## starter — CT02/CT03/CT12/CT14
Нужны CMake 3.21+, Ninja, C++20. CMake 3.28 подходит. Из starter:

~~~sh
cmake --preset dev
cmake --build --preset dev
ctest --preset dev --no-tests=error
~~~

Linux: ./build/dev/app --help
Windows cmd: build\dev\app.exe --help
PowerShell: .\build\dev\app.exe --help

Без аргументов вывод 5, --version выводит devtools-lab 0.1.0. Неизвестный аргумент даёт код 2.
Это минимальная лаборатория инструментов; в NMS сохраняется QCommandLineParser.
Если Windows выбрала не cl, удали только build этой лаборатории и повтори:
cmake --preset dev -DCMAKE_CXX_COMPILER=cl
Не переключай компилятор в старом кэше.
Release: замени dev на release. Тесты используют явные проверки, не исчезающий assert.
Отрицательный опыт: a + b временно замени на a - b; пересобери и получи отказ теста, затем восстанови.

После Release:
~~~sh
cmake --install build/release --prefix stage
cpack --config build/release/CPackConfig.cmake
~~~
CPack не обещает включить все runtime-зависимости: проверь комплект на чистой целевой ОС.
Dockerfile — дополнительная Linux-лаборатория CT14.1; digest и версии пакетов здесь не зафиксированы.

## gdb — CT04–CT09, Linux GCC/Clang
Здесь Linux API и GCC/Clang атрибуты. Нативная MSVC-отладка находится в CT10.
Из gdb:

~~~sh
g++ -std=c++20 -g -O0 -fno-omit-frame-pointer -pthread gdb-lab.cpp -o gdb-lab
./gdb-lab sum
gdb --args ./gdb-lab sum
~~~

Ожидается word=305419896 sum=16. В GDB:
~~~text
break step_value
run
info args
print value
bt
next
continue
quit
~~~

break ставит точку, run запускает, bt показывает вызовы, next выполняет строку без входа в функцию.
Все файлы собираются также командами cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Debug и cmake --build build.

- gdb-lab sum: обычные значения и стек.
- gdb-lab throw: перехваченное исключение.
- gdb-lab abort: НАМЕРЕННЫЙ SIGABRT для CT06/CT07; дамп зависит от ОС.
- gdb-lab wait: ожидание 15 секунд.
- mutex-lab: ограниченное ожидание timed_mutex, не бесконечный deadlock.
- range-sum: НАМЕРЕННАЯ логическая ошибка; actual=8 expected=16, код 1. Исправление — CT09.3.
- fork-lab: родитель и потомок Linux.
- reverse-lab: простая C-программа; возможность record/reverse зависит от стенда.

CT08.1: gdb -q -batch -x check-inputs.gdb --args ./gdb-lab sum
CT08.2: source show-inputs.py внутри GDB, остановись в step_value, затем show-inputs.
Сначала прочитай скрипты. Обычный Python не содержит модуль gdb. Не отключай глобально auto-load safe-path.

## asm-pair — AX06, x86-64 Windows/Linux
C++-тест и две реализации сложения uint64_t по модулю 2^64.
Linux: RDI/RSI, NASM ELF64. Windows: RCX/RDX, MASM. Leaf-функция не меняет стек.
Контракт не доказывает ускорение и не покрывает сложный unwind.
Из asm-pair, Linux:
~~~sh
cmake -S . -B build-linux -G Ninja -DCMAKE_BUILD_TYPE=Debug
cmake --build build-linux
ctest --test-dir build-linux --output-on-failure --no-tests=error
~~~
Windows, x64 Developer Command Prompt:
~~~text
cmake -S . -B build-windows -G Ninja -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CXX_COMPILER=cl
cmake --build build-windows
ctest --test-dir build-windows --output-on-failure --no-tests=error
~~~
Четыре случая, включая unsigned wraparound. Для генератора Visual Studio 18 2026 нужен CMake 4.2+, здесь Ninja.
Этот ASM не подходит для ARM64.

## Отчёт и проверка
Заполни REPORT-TEMPLATE.md для одной задачи. Приложи код и команды.
Прогресс сайта хранится в браузере: экспортируй JSON для переноса; архив кода не является экспортом прогресса.
Историческая проверка 18 октября 2026: Linux C++/C/NASM, CMake/CTest и намеренные отказы проверены.
18 октября GDB проверялся статически: символы, дизассемблер, help и Python-команда. В среде подготовки запрещён ptrace, поэтому live-сессии, core, TUI, remote, reverse и watchpoints здесь не подтверждены.
Windows/MSVC/MASM, VS/WinDbg, Docker, hosted CI и GUI не запускались: их выполнение требуется на соответствующем стенде.

## Автоматическая живая проверка GDB — 26 октября 2026
Из корня распакованного cpp-devtools-labs:

~~~sh
sudo apt update
sudo apt install build-essential gdb gdbserver cmake ninja-build nasm python3
python3 verify-live.py --output gdb-verification
~~~

Сценарий создаёт временные бинарники, запускает настоящие процессы под GDB и сохраняет report.json и журналы. Возврат 0 означает успех всех проверок; запрет ptrace даёт blocked и ненулевой код, а не PASS. Упражнения и прогресс сайта не меняются. Намеренный дефект range-sum остаётся в исходнике; исправленная копия и четыре регрессии проверяются во временной папке. Перед запуском прочитай сценарий.

Ubuntu 24.04 в WSL 2 и Kubuntu используют одинаковые Bash-команды. Храни рабочую копию в ~/projects; не переноси build между Windows и Linux. Автоматическая проверка на отдельном Linux-раннере не заменяет запуск на твоём ядре WSL/Kubuntu. TUI, системный сбор crash-core, rr, SSH к реальному стенду и Windows требуют отдельной проверки. Скрипт attach проверяет дочерний процесс самого GDB, а обычный attach к соседнему процессу может запрещаться Yama.

Результат повторной проверки 26 октября 2026: 25/25 живых GDB-проверок успешно на Ubuntu 24.04.5, GDB 15.1, GCC 13.3. Исправлена обработка ValueError в show-inputs.py. Журналы: https://github.com/nspace0/cpp_roadmap/actions/runs/40296124602 . Это техническая проверка лабораторий, не отметка о прохождении уроков пользователем.
