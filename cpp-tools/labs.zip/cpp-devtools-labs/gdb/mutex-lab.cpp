#include <atomic>
#include <barrier>
#include <chrono>
#include <iostream>
#include <mutex>
#include <thread>

std::timed_mutex first_mutex, second_mutex;
std::barrier rendezvous(2);
std::atomic<int> waiting{0};
std::atomic<int> timed_out{0};

__attribute__((noinline)) void snapshot_marker() {
    std::cout << "snapshot: both workers reached second lock\n";
}

void worker(std::timed_mutex& first, std::timed_mutex& second) {
    std::unique_lock first_lock(first);
    rendezvous.arrive_and_wait();
    waiting.fetch_add(1);
    std::unique_lock second_lock(second, std::defer_lock);
    if (!second_lock.try_lock_for(std::chrono::seconds(5))) {
        timed_out.fetch_add(1);
    }
}

int main() {
    std::thread a(worker, std::ref(first_mutex), std::ref(second_mutex));
    std::thread b(worker, std::ref(second_mutex), std::ref(first_mutex));
    while (waiting.load() != 2) {
        std::this_thread::yield();
    }
    snapshot_marker();
    a.join();
    b.join();
    std::cout << "timeouts=" << timed_out.load() << '\n';
}
