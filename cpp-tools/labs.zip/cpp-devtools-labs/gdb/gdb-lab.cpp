#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

int watched = 0;

// GCC/Clang extension keeps this teaching boundary visible at -Og/-O2.
__attribute__((noinline)) int step_value(int value, int index) {
    watched = value + index;
    return value;
}

__attribute__((noinline)) long sum_values(const int* data, std::size_t count) {
    long total = 0;
    for (std::size_t i = 0; i < count; ++i) {
        total += step_value(data[i], static_cast<int>(i));
    }
    return total;
}

__attribute__((noinline)) void inspect_values(
    const std::vector<int>& values, std::uint32_t word) {
    const int* data = values.data();
    const std::size_t count = values.size();
    std::cout << "word=" << word << " sum=" << sum_values(data, count) << '\n';
}

__attribute__((noinline)) int checked_value(
    const std::vector<int>& values, std::size_t index) {
    if (index >= values.size()) {
        throw std::out_of_range("index outside values");
    }
    return values[index];
}

int main(int argc, char** argv) {
    const std::string mode = argc > 1 ? argv[1] : "sum";
    const std::vector<int> values{3, 5, 8};
    const std::uint32_t word = 0x12345678u;
    if (mode == "sum") {
        inspect_values(values, word);
        return 0;
    }
    if (mode == "throw") {
        try {
            std::cout << checked_value(values, 8) << '\n';
        } catch (const std::out_of_range& e) {
            std::cout << "caught: " << e.what() << '\n';
        }
        return 0;
    }
    if (mode == "abort") {
        std::abort(); // Deliberate SIGABRT lesson; does not corrupt memory.
    }
    if (mode == "wait") {
        std::cout << "waiting 15 seconds\n" << std::flush;
        std::this_thread::sleep_for(std::chrono::seconds(15));
        return 0;
    }
    std::cerr << "usage: gdb-lab [sum|throw|abort|wait]\n";
    return 2;
}
