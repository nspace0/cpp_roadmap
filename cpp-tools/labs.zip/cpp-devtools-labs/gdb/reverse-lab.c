volatile int value = 0;
int main(void) {
    value = 1;
    value = value + 2;
    value = value * 3;
    return value == 9 ? 0 : 1;
}
