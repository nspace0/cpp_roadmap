set pagination off
set confirm off
set logging file gdb-inputs.log
set logging overwrite on
set logging enabled on
break step_value if index == 2
run
printf "Observed final input: index=%d value=%d\n", index, value
bt 4
if index != 2 || value != 8
    echo Unexpected input at step_value\n
    quit 1
end
set logging enabled off
quit 0
