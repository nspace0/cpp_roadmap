"""Explicitly source this trusted file from GDB; ordinary Python cannot import gdb."""
import gdb

class ShowInputs(gdb.Command):
    """Print step_value arguments without calling functions in the inferior."""
    def __init__(self):
        super().__init__("show-inputs", gdb.COMMAND_DATA)

    def invoke(self, argument, from_tty):
        self.dont_repeat()
        if argument.strip():
            raise gdb.GdbError("Usage: show-inputs")
        try:
            frame = gdb.selected_frame()
            value = frame.read_var("value")
            index = frame.read_var("index")
            if value.is_optimized_out or index.is_optimized_out:
                raise gdb.GdbError("Arguments are optimized out in this frame")
            gdb.write(f"index={int(index)} value={int(value)}\n")
        except gdb.error as exc:
            raise gdb.GdbError(f"Select the step_value frame first: {exc}")

ShowInputs()
