#include <cstddef>
#include <iostream>
#include <vector>

__attribute__((noinline)) long range_sum(const std::vector<int>& values) {
    long total = 0;
    // Deliberate teaching bug: the final element is skipped.
    for (std::size_t i = 0; i + 1 < values.size(); ++i) {
        total += values[i];
    }
    return total;
}

int main() {
    const std::vector<int> values{3, 5, 8};
    const long result = range_sum(values);
    std::cout << "actual=" << result << " expected=16\n";
    return result == 16 ? 0 : 1;
}
