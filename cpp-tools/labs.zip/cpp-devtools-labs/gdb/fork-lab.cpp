#include <cerrno>
#include <cstdio>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main() {
    const pid_t child = fork();
    if (child < 0) { std::perror("fork"); return 1; }
    if (child == 0) {
        execl("/bin/true", "true", static_cast<char*>(nullptr));
        std::perror("execl");
        _exit(127);
    }
    int status = 0;
    pid_t waited;
    do { waited = waitpid(child, &status, 0); } while (waited < 0 && errno == EINTR);
    if (waited < 0) { std::perror("waitpid"); return 1; }
    return WIFEXITED(status) && WEXITSTATUS(status) == 0 ? 0 : 1;
}
